#!/usr/bin/env python
# -*- coding:utf-8 -*-
from distutils.core import setup

setup(
    name='nester',
    version='1.0.0',
    py_modules=['nester'],
    author         ='Dodd',
    author_email    ='hfpython@headfirstlabs.com',
    url             ='http://www.headfirstlabs.com',
    description     ='A simple print function for nested list.'
)